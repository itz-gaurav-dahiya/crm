<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Technician;

class TechnicianController extends Controller
{
    public function index()
    {
        return response()->json(
            Technician::where('status', 'active')->get()
        );
    }

    public function store(Request $request)
    {
        $technician = Technician::create([
            'name' => $request->name,
            'phone' => $request->phone,
            'status' => 'active'
        ]);

        return response()->json($technician);
    }
}