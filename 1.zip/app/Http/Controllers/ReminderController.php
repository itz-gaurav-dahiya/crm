<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ReminderController extends Controller
{
    public function dueCustomers()
    {
        $today = now();

        $customers = Customer::all();

        $dueCustomers = [];

        foreach ($customers as $customer)
        {
            if (!$customer->service_date)
            {
                continue;
            }

            $nextService = Carbon::parse($customer->service_date)->addMonths(3);

            if ($nextService <= $today)
            {
                $dueCustomers[] = [
                    'name' => $customer->customer_name,
                    'phone' => $customer->phone,
                    'technician' => $customer->technician_name,
                    'last_service' => $customer->service_date,
                    'next_service' => $nextService->format('d-m-Y')
                ];
            }
        }

        return response()->json($dueCustomers);
    }
}
