<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Carbon\Carbon;

class CustomerController extends Controller
{
    // GET ALL CUSTOMERS
    public function index()
    {
        return response()->json(Customer::all());
    }

    // CREATE CUSTOMER
    public function store(Request $request)
    {
        try {

            $totalAmount = $request->total_amount ?: 0;
            $spendAmount = $request->spend_amount ?: 0;

            $profit = $totalAmount - $spendAmount;

            // safe date handling
            $serviceDate = !empty($request->service_date)
                ? Carbon::parse($request->service_date)
                : now();

            $customer = Customer::create([
                'customer_name'   => $request->customer_name ?? '',
                'phone'           => $request->phone ?? '',
                'address'         => $request->address ?? '',
                'work'            => $request->work ?? '',
                'technician_name' => $request->technician_name ?? '',

                'total_amount'    => $totalAmount,
                'spend_amount'    => $spendAmount,

                // calculations
                'profit'          => $profit,
                'profit_share'    => $profit / 2,

                // dates
                'service_date'    => $serviceDate->format('Y-m-d'),
                'reminder_date'   => $serviceDate->copy()->addMonths(3)->format('Y-m-d'),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Customer Added Successfully',
                'data' => $customer
            ], 201);

        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // UPDATE CUSTOMER
    public function update(Request $request, Customer $customer)
    {
        try {

            $totalAmount = $request->total_amount ?: 0;
            $spendAmount = $request->spend_amount ?: 0;

            $profit = $totalAmount - $spendAmount;

            $serviceDate = !empty($request->service_date)
                ? Carbon::parse($request->service_date)
                : $customer->service_date;

            $customer->update([
                'customer_name'   => $request->customer_name ?? $customer->customer_name,
                'phone'           => $request->phone ?? $customer->phone,
                'address'         => $request->address ?? $customer->address,
                'work'            => $request->work ?? $customer->work,
                'technician_name' => $request->technician_name ?? $customer->technician_name,

                'total_amount'    => $totalAmount,
                'spend_amount'    => $spendAmount,

                'profit'          => $profit,
                'profit_share'    => $profit / 2,

                'service_date'    => $serviceDate->format('Y-m-d'),
                'reminder_date'   => $serviceDate->copy()->addMonths(3)->format('Y-m-d'),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Customer Updated Successfully',
                'data' => $customer
            ]);

        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // DELETE CUSTOMER
    public function destroy(Customer $customer)
    {
        try {

            $customer->delete();

            return response()->json([
                'success' => true,
                'message' => 'Customer Deleted Successfully'
            ]);

        } catch (\Throwable $e) {

            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }
}