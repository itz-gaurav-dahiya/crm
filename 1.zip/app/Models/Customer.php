<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    // table name (optional but safe)
    protected $table = 'customers';

    // allow mass assignment
    protected $fillable = [
        'customer_name',
        'phone',
        'address',
        'work',
        'technician_name',
        'total_amount',
        'spend_amount',
        'profit',
        'profit_share',
        'service_date',
        'reminder_date'
    ];

    // date casting (important for Laravel handling)
    protected $casts = [
        'service_date' => 'date',
        'reminder_date' => 'date',
        'total_amount' => 'decimal:2',
        'spend_amount' => 'decimal:2',
        'profit' => 'decimal:2',
        'profit_share' => 'decimal:2',
    ];
public function technician()
{
    return $this->belongsTo(Technician::class);
}
    }