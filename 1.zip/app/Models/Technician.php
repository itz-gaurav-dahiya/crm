<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Technician extends Model
{
    protected $fillable = [
        'name',
        'phone',
        'status'
    ];

    public function customers()
    {
        return $this->hasMany(Customer::class);
    }
}