<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customers', function (Blueprint $table) {
$table->id();

$table->string('customer_name');
$table->string('phone');
$table->text('address')->nullable();

$table->string('work');
$table->string('technician_name');

$table->decimal('total_amount', 10, 2);
$table->decimal('spend_amount', 10, 2);

$table->decimal('profit', 10, 2)->default(0);
$table->decimal('profit_share', 10, 2)->default(0);

$table->date('service_date');
$table->date('reminder_date');

$table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customers');
    }
};
